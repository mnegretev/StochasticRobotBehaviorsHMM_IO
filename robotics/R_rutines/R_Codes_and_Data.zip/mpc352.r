R commands and output:

alpha = 0.05
k = 6
t = qt(1-alpha/2, k-1)
t

> [1] 2.570582

