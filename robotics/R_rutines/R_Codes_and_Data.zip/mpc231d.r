R commands and output:

alpha = 0.05
J = 6
K = 6
F = qf(1-alpha, J-1, K*(J-1))
F

> [1] 2.533555
