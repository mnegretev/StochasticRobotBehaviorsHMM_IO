var searchData=
[
  ['error',['error',['../mdp_8c.html#add0c2c2ef77a3536f92911511c213674',1,'error(MDP *mdp, float *v):&#160;mdp.c'],['../mdp_8h.html#add0c2c2ef77a3536f92911511c213674',1,'error(MDP *mdp, float *v):&#160;mdp.c']]],
  ['expected_5fu',['expected_u',['../mdp_8c.html#a58f24d49e4244f9735f1230e9498b1e1',1,'expected_u(MDP *mdp, int s, int a):&#160;mdp.c'],['../mdp_8h.html#a58f24d49e4244f9735f1230e9498b1e1',1,'expected_u(MDP *mdp, int s, int a):&#160;mdp.c']]]
];
