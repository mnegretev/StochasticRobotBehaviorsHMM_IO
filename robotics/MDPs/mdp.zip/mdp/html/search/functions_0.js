var searchData=
[
  ['allocate_5fmdp',['allocate_MDP',['../mdp_8c.html#a22c6426ddba7afdee5abb7ea99d2b17c',1,'allocate_MDP(int s, int a, float gamma):&#160;mdp.c'],['../mdp_8h.html#a22c6426ddba7afdee5abb7ea99d2b17c',1,'allocate_MDP(int s, int a, float gamma):&#160;mdp.c']]]
];
