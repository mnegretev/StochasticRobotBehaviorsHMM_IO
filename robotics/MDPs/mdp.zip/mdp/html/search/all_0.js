var searchData=
[
  ['a',['a',['../structMDP.html#ae25a44e2b3d9f22a4f3fd6296b3602c5',1,'MDP']]],
  ['allocate_5fmdp',['allocate_MDP',['../mdp_8c.html#a22c6426ddba7afdee5abb7ea99d2b17c',1,'allocate_MDP(int s, int a, float gamma):&#160;mdp.c'],['../mdp_8h.html#a22c6426ddba7afdee5abb7ea99d2b17c',1,'allocate_MDP(int s, int a, float gamma):&#160;mdp.c']]]
];
