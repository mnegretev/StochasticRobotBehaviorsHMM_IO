var searchData=
[
  ['compute_5foptimal_5fpolicy',['compute_optimal_policy',['../mdp_8c.html#a51e90fe5febf5a94747885f4c4f01e1c',1,'compute_optimal_policy(MDP *mdp):&#160;mdp.c'],['../mdp_8h.html#a51e90fe5febf5a94747885f4c4f01e1c',1,'compute_optimal_policy(MDP *mdp):&#160;mdp.c']]]
];
