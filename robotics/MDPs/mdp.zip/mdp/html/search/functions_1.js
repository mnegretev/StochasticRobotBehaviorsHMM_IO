var searchData=
[
  ['best_5fexpected_5faction',['best_expected_action',['../mdp_8c.html#a66fa752860782c0eda6d1c6a30af4028',1,'best_expected_action(MDP *mdp, int s):&#160;mdp.c'],['../mdp_8h.html#a66fa752860782c0eda6d1c6a30af4028',1,'best_expected_action(MDP *mdp, int s):&#160;mdp.c']]],
  ['best_5fexpected_5fu',['best_expected_u',['../mdp_8c.html#a1657efbb6ac6751151b54828cda44baa',1,'best_expected_u(MDP *mdp, int s):&#160;mdp.c'],['../mdp_8h.html#a1657efbb6ac6751151b54828cda44baa',1,'best_expected_u(MDP *mdp, int s):&#160;mdp.c']]]
];
